package mark.nilov.game;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.SurfaceHolder;
import android.widget.ImageView;


public class GameView extends SurfaceView implements SurfaceHolder.Callback {
    private MainThread thread;
    private CharacterSprite characterSprite;
    private EnemySprite enemySprite;
    private PlatformManager platform;
    private ImageView imageView;
    private Bitmap bitmap;
    private RectPlayer player;
    private boolean gameover = false;
    private long gameOverTime;
    Activity a;
    private Animation forest;
    private AnimationManager backgroundManager;
    private Rect screen = new Rect(-650,-650,1600,1900);



    private String lastscore = "lastscore";
    private String highscore = "highscore";


    public GameView(Context context){
        super(context);

        getHolder().addCallback(this);

        Constants.CURRENT_CONTEXT = context;

        thread = new MainThread(getHolder(),this);
        setFocusable(true);
        a = (Activity) context;

    }

    public void reset(){

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height){

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder){
      //  characterSprite = new CharacterSprite(BitmapFactory.decodeResource(getResources(),R.drawable.charsprite));
        //enemySprite = new EnemySprite(BitmapFactory.decodeResource(getResources(),R.drawable.enemysprite));
        BitmapFactory bf = new BitmapFactory();
        Bitmap forestBackground = bf.decodeResource(Constants.CURRENT_CONTEXT.getResources(),R.drawable.forestbackground);
        forest = new Animation(new Bitmap[]{forestBackground},2);
        backgroundManager = new AnimationManager(new Animation[]{forest});

        platform = new PlatformManager(1000);
        //playerPoint = new Point(100,100);
        player = new RectPlayer(new Rect(2400,100,2500,200), Color.rgb(255,0,0));
        thread.setRunning(true);
        thread.start();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder){
        boolean retry = true;
        while(retry){
            try{
                thread.setRunning(false);
                thread.join();
            } catch(InterruptedException e){
                e.printStackTrace();
            }
            retry = false;
        }

    }

    public void update(){

       /* imageView = (ImageView) findViewById(R.id.GameView);
        imageView.setDrawingCacheEnabled(true);
        imageView.buildDrawingCache(true);
        bitmap = imageView.getDrawingCache();
        int pixel = bitmap.getPixel(100,200);
*/
        //characterSprite.update();

        if(!gameover){
            backgroundManager.playAnim(0);
            backgroundManager.update();
        platform.update();
        player.update();
        if(platform.playerCollide(player)){
            player.collision();
        }
        else{
            player.nocollision();
        }
        if(player.getPos() < 10){
            gameover = true;
            gameOverTime = System.currentTimeMillis();
        }
        }

    }

    @Override
    public void draw(Canvas canvas){
        super.draw(canvas);
        backgroundManager.draw(canvas,screen);

        //if(canvas != null){
            //enemySprite.draw(canvas);
            //characterSprite.draw(canvas);
        player.draw(canvas);
        platform.draw(canvas);

        if(gameover){
            Paint paint2 = new Paint();
            paint2.setTextSize(100);
            paint2.setColor(Color.MAGENTA);
            canvas.rotate(90,500,600);
            canvas.drawText("Game Over",500,600,paint2);
            canvas.drawText(""+platform.getScore(),1500,200,paint2);

            SharedPreferences prefs2 = getContext().getSharedPreferences("highScore", Context.MODE_PRIVATE);
            int score = prefs2.getInt("highScore", 0);
            if(platform.getScore()>score){
                SharedPreferences.Editor editor = prefs2.edit();
                editor.putInt("highScore", platform.getScore());
                editor.commit();
            }

            SharedPreferences prefs = getContext().getSharedPreferences("lastScore", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putInt("lastScore", platform.getScore());
            editor.commit();
        }

        Paint paint = new Paint();
        paint.setTextSize(100);
        paint.setColor(Color.MAGENTA);
        canvas.rotate(90,900,1600);
        canvas.drawText(""+platform.getScore(),900,1600,paint);
          //  enemySprite.draw(canvas);
        //}
    }
    @Override
    public boolean onTouchEvent(MotionEvent event){
        int action = event.getActionMasked();

        switch(action) {
            case MotionEvent.ACTION_DOWN:
            //characterSprite.jump();
            player.jump();
            if(gameover){
                gameover = false;
                //lags a bit, why?
                Intent startIntent = new Intent(getContext(),MainActivity.class);
                getContext().startActivity(startIntent);
            }
            break;
        }
        return super.onTouchEvent(event);
    }

}
