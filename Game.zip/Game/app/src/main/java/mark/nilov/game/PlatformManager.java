package mark.nilov.game;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

import java.util.ArrayList;

public class PlatformManager {
    private ArrayList<Platform> platforms;
    private int platformGap;
    private int counter;
    private int score = 0;
    //private int playerGap;

    private long startTime;

    public PlatformManager(int platformGap){
        this.platformGap = platformGap;
        startTime = System.currentTimeMillis();
        platforms = new ArrayList<>();
        populatePlatforms();
    }

    public boolean playerCollide(RectPlayer player){
        for(Platform pl : platforms){
            if(pl.playerCollide(player))
                return true;
        }
        return false;
    }

    private void populatePlatforms(){
        int currY = -5*Constants.SCREEN_HEIGHT/4;
        while(currY<0){
            int xStart = (int)(Math.random()*(Constants.SCREEN_WIDTH));
            platforms.add(new Platform(300));
            platforms.add(new Platform(600));
            currY += platformGap;
        }
    }
    public void update(){
        int elapsedTime = (int)(System.currentTimeMillis() - startTime);
        startTime = System.currentTimeMillis();
        float speed = Constants.SCREEN_HEIGHT/10000.0f;
        for(Platform pl:platforms){
            pl.incrementY(speed + elapsedTime);
        }
        if(counter == 45){
            int xStart = (int)(Math.random()*(Constants.SCREEN_WIDTH));
            platforms.add(0,new Platform(xStart));
            xStart = (int)(Math.random()*(Constants.SCREEN_WIDTH));
            platforms.add(0,new Platform(xStart));
            xStart = (int)(Math.random()*(Constants.SCREEN_WIDTH));
            platforms.add(0,new Platform(xStart));
            counter =0;
            score++;
            //platforms.remove(platforms.size()-1);
        }
    }
    public void draw(Canvas canvas){
        for (Platform pl : platforms){
            pl.draw(canvas);
        }
        counter++;
    }
    public int getScore(){
        return score;
    }
}

//platform gap = gap between platforms, (up down)
//use player gap instead I THINK
