package mark.nilov.game;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;


public class MainActivity extends Activity {
    private TextView lastscore;
    private TextView highscore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        Constants.SCREEN_WIDTH = dm.widthPixels;
        Constants.SCREEN_HEIGHT = dm.heightPixels;

        setContentView(R.layout.activity_main);
        lastscore = findViewById(R.id.lastScore);
        SharedPreferences prefs = this.getSharedPreferences("lastScore", Context.MODE_PRIVATE);
        int score = prefs.getInt("lastScore", 0);
        DecimalFormat precision = new DecimalFormat("0");
        lastscore.setText(precision.format(score));

        highscore = findViewById(R.id.highScore);
        SharedPreferences prefs2 = this.getSharedPreferences("highScore", Context.MODE_PRIVATE);
        int score2 = prefs2.getInt("highScore", 0);
        highscore.setText(precision.format(score2));


        Button btnPlay = (Button) findViewById(R.id.button);
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setContentView(new GameView(MainActivity.this));
        }
        });
    }
}
