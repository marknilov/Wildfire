package mark.nilov.game;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.Log;

public class CharacterSprite {
    private Bitmap image;
    private int x,y;
    int flag = 0;
    int landing = 0;

    public CharacterSprite(Bitmap bmp){
        image = bmp;
        x = 100;
        y = 100;
    }
    public void draw(Canvas canvas){
        canvas.drawBitmap(image,x,y,null);
    }
    public void update(){

        //decent
        if(flag == 0 && x>100) {
            x = x-7;
        }
        //ascension
        //could add a double jump aswell
        if(flag == 1 && x<600){
            x = x+10;
            landing = 1;
        }
        //peak
        if(x>300){
            flag = 0;
        }
        //grounded
        if(x == 100){
            landing = 0;
        }
        //forward movement
        //y = y+5;
        //reset loop
        //if(y >1800){
        //    y = 100;
        //}
    }
    public void jump(){
        //begins the jump
        if(landing == 0){
            flag = 1;
        }
    }
}
