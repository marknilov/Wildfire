package mark.nilov.game;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;

public class RectPlayer {
    private Rect rectangle;
    private int color;
    int flag = 0;
    int colide = 0;
    int aircounter = 0;
    int state = 0;

    private Animation walk;
    private AnimationManager animManager;

    public RectPlayer(Rect rectangle, int color){
        this.rectangle = rectangle;
        this.color = color;

        BitmapFactory bf = new BitmapFactory();
        Bitmap walk1 = bf.decodeResource(Constants.CURRENT_CONTEXT.getResources(),R.drawable.charsprite1);
        Bitmap walk2 = bf.decodeResource(Constants.CURRENT_CONTEXT.getResources(),R.drawable.charsprite2);
        Bitmap walk3 = bf.decodeResource(Constants.CURRENT_CONTEXT.getResources(),R.drawable.charsprite3);
        Bitmap walk4 = bf.decodeResource(Constants.CURRENT_CONTEXT.getResources(),R.drawable.charsprite4);

        walk = new Animation(new Bitmap[]{walk1,walk2,walk3,walk4},1);

        //all my walks here
        animManager = new AnimationManager(new Animation[]{walk});
    }

    public void draw(Canvas canvas){
     //   Paint paint = new Paint();
     //   paint.setColor(color);
     //   canvas.drawRect(rectangle,paint);

        animManager.draw(canvas,rectangle);
    }

    public void update(){
        //animation
        //may not have need for this, maybe to jump
        animManager.playAnim(state);
        animManager.update();

        //decent
        if(colide == 0){
            rectangle.offset(-20,0);
            //grounded
        }
        //ascent
        if(flag == 1 && colide == 1){
            rectangle.offset(25,0);
            aircounter = aircounter + 1;
        }
        //peak
        if(aircounter == 20){
            flag = 0;
            aircounter = 0;
        }
        /*
        //decent
        if(flag == 0 && rectangle.centerX()>100) {
            rectangle.offset(-7,0);
        }
        //ascension
        //could add a double jump aswell
        if(flag == 1 && rectangle.centerX()<600){
            rectangle.offset(10,0);
            landing = 1;
        }
        //peak
        if(rectangle.centerX()>300){
            flag = 0;
        }
        //grounded
        if(rectangle.centerX() >= 100 && rectangle.centerX() <= 110){
            landing = 0;
        }*/
    }
    public void jump(){
        //begins the jump
        if(colide == 1){
            flag = 1;}

    }
    public Rect getRectangle(){
        return rectangle;
    }
    public void collision(){
        colide = 1;
    }
    public void nocollision(){
        if(flag == 0){
        colide = 0;}
    }
    public int getPos(){
        return rectangle.centerX();
    }

}
