package mark.nilov.game;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

public class Platform {
    private Rect rectangle;
    private int color;

    public Rect getRectangle(){
        return rectangle;
    }

    public void incrementY(float y){
        rectangle.top -=y;
        rectangle.bottom -=y;
    }

    public Platform(int startX){
        //left, top
        //          right,bottom
        rectangle = new Rect(startX,1800,(startX - 10),2100);
        color = Color.LTGRAY;
    }

    public boolean playerCollide(RectPlayer player){
        return Rect.intersects(rectangle,player.getRectangle());
    }

    public void draw(Canvas canvas){
        Paint paint = new Paint();
        paint.setColor(color);
        canvas.drawRect(rectangle,paint);
    }
    public void update(){

    }
}
