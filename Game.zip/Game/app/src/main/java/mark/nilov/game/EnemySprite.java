package mark.nilov.game;

import android.graphics.Bitmap;
import android.graphics.Canvas;

public class EnemySprite {
    private Bitmap image;
    private int x,y;
    public EnemySprite(Bitmap bmp){
        image = bmp;
        x = 80;
        y = 1000;
    }
    public void draw(Canvas canvas){
        canvas.drawBitmap(image,x,y,null);
    }
    public void update(){

    }
}
